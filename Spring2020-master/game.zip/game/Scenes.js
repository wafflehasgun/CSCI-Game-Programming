import SceneOne from "./scenes/SceneOne.js"
import SceneTwo from "./scenes/SceneTwo.js"

export default{
  SceneOne,
  SceneTwo,
}