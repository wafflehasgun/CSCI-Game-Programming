import Base from "./Base.js"
import Components from "./Components.js"

export default{
  Base,
  Components
}