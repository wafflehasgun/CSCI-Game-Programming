export default class NameableParent {
    children = [];
    name = "";
}