import GameObject from "./GameObject.js"

export default class Camera extends GameObject{
    
    backgroundColor = "black";

    constructor(){

    }
}