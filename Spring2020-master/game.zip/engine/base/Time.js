export default class Time{
    static deltaTime = 0;
}