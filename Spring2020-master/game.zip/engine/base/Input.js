export default class Input{
    static keys = [];
}