export default class Component{

    //Reference to containing GameObject
    gameObject;
    

}