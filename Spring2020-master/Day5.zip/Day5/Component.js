class Component{
    gameObject;
    

}

export default Component;